
#!/usr/bin/python3

##Used for pure ATAC (Acs modality)  ##Example used was Enh-Silent
import numpy as np
import pandas as pd
import math
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split  ##To split data in training and test 
from sklearn import metrics
from sklearn.metrics import roc_auc_score
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler  ##to standardise data
from sklearn.model_selection import RandomizedSearchCV
from sklearn.linear_model import LogisticRegressionCV
import scikitplot as skplt   ##to build plots
from sklearn.manifold import TSNE  ##dimensionality reduction
import seaborn as sns
#sns.set(style="white")

## set paths and filenames ##

# general data directory (where I have put the matrices)
data_dir = '/Users/ernestomanuell/Desktop/Materias maestría/Dissertation Project'

## directory for matrices
matrix_dir = data_dir + '/' + 'matrices'

state1='Enh'
state0='ReprPC,Quies,Het'
trainingday='11.5'
testday1='12.5'
testday2='13.5'

## training Matrices filenames
file1Train = 'Matrixfor_'+state1+'_'+trainingday+'_withATAC.tsv'  #'Matrixfor_Enh_11.5.tsv'
file0Train='Matrixfor_'+state0+'_'+trainingday+'_withATAC.tsv'  #'Matrixfor_Silent_11.5.tsv'

## testing Matrices Day 12.5 filenames
file1Test = 'Matrixfor_'+state1+'_'+testday1+'_withATAC.tsv'   #'Matrixfor_Enh_12.5.tsv'
file0Test='Matrixfor_'+state0+'_'+testday1+'_withATAC.tsv' #'Matrixfor_Silent_12.5.tsv'

## testing Matrices Day 13.5 filenames
file1Test2 = 'Matrixfor_'+state1+'_'+testday2+'_withATAC.tsv' #'Matrixfor_Enh_13.5.tsv'
file0Test2='Matrixfor_'+state0+'_'+testday2+'_withATAC.tsv' #'Matrixfor_Silent_13.5.tsv'

##Training dataset
featmat1Train_df = pd.read_csv(matrix_dir+'/'+file1Train,header=None,sep='\t')
featmat0Train_df = pd.read_csv(matrix_dir+'/'+file0Train,header=None,sep='\t')

##Testing dataset 1
featmat1Test_df = pd.read_csv(matrix_dir+'/'+file1Test,header=None,sep='\t')
featmat0Test_df = pd.read_csv(matrix_dir+'/'+file0Test,header=None,sep='\t')

##Testing dataset 2
featmat1Test2_df = pd.read_csv(matrix_dir+'/'+file1Test2,header=None,sep='\t')
featmat0Test2_df = pd.read_csv(matrix_dir+'/'+file0Test2,header=None,sep='\t')

##Training dataset
featmat1Train_df=featmat1Train_df.iloc[1:,-1]
featmat0Train_df=featmat0Train_df.iloc[1:,-1]

##Testing dataset
featmat1Test_df =featmat1Test_df.iloc[1:,-1]
featmat0Test_df=featmat0Test_df.iloc[1:,-1]

##Testing dataset 2
featmat1Test2_df =featmat1Test2_df.iloc[1:,-1]
featmat0Test2_df=featmat0Test2_df.iloc[1:,-1]

X_train=pd.concat([featmat1Train_df,featmat0Train_df])
len(X_train)

##Testing dataset 12.5
X_test=pd.concat([featmat1Test_df,featmat0Test_df])
len(X_test)

##Testing dataset 13.5
X_test2=pd.concat([featmat1Test2_df,featmat0Test2_df])
len(X_test2)

##Y variable has to be as long as the "samples" in this case peaks in each dataset (the number of rows).
#The column headers or motifs are the "features".
x1=np.ones(len(featmat1Train_df)) ##Enh
y1=np.zeros(len(featmat0Train_df)) ##Silent
y_train=np.hstack([x1,y1])
len(y_train)

##Labelling for day 12.5
x2=np.ones(len(featmat1Test_df))  #Enh
y2=np.zeros(len(featmat0Test_df)) ##Silent
y_test=np.hstack([x2,y2])
len(y_test)

##Labelling for day 13.5
x3=np.ones(len(featmat1Test2_df))  #Enh
y3=np.zeros(len(featmat0Test2_df)) ##Silent
y_test2=np.hstack([x3,y3])
len(y_test2)

X_train=np.reshape(np.ravel(X_train),(-1, 1))
X_test=np.reshape(np.ravel(X_test),(-1, 1))
X_test2=np.reshape(np.ravel(X_test2),(-1, 1))

##Fit on TRAINING data
scaler = StandardScaler()
scaler.fit(X_train)

##Standardise both training and testing independent values (samples)
X_train_stand=scaler.transform(X_train)
X_test_stand=scaler.transform(X_test)
X_test2_stand=scaler.transform(X_test2)

logreg = LogisticRegressionCV(cv=5, random_state=42, scoring='balanced_accuracy',class_weight='balanced', max_iter=3000)

logreg.fit(X_train_stand, y_train)
print (logreg.C_)
print (logreg.intercept_)
print (logreg.coef_)

##Metrics for training data (11.5)
y_pred=logreg.predict(X_train_stand)
from sklearn.metrics import classification_report

print(classification_report(y_train, y_pred))

##Metrics for test day 12.5
y_pred_test=logreg.predict(X_test_stand)
from sklearn.metrics import classification_report

print(classification_report(y_test, y_pred_test))

##Metrics for test day 13.5
y_pred_test2=logreg.predict(X_test2_stand)
from sklearn.metrics import classification_report

print(classification_report(y_test2, y_pred_test2))

##Confusion matrices
cm=metrics.confusion_matrix(y_test,y_pred_test)
print (cm)

cm2=metrics.confusion_matrix(y_test2,y_pred_test2)
print (cm2)

##ROC AUC scores

##ROC curve for day 12.5
probtest=logreg.predict_proba(X_test_stand)

print(roc_auc_score(y_test, probtest[:,1]))
skplt.metrics.plot_roc(
 y_test, probtest, title="Roc Curve",
 figsize=(10, 8))
 
##ROC curve for day 13.5
probtest2=logreg.predict_proba(X_test2_stand)

print(roc_auc_score(y_test2, probtest2[:,1]))
skplt.metrics.plot_roc(
 y_test2, probtest2, title="Roc Curve",
 figsize=(10, 8))

