
#!/usr/bin/python3

##Motif importance and biological validation done for MFS modality. Example given for Enh-EnhPr

from gtfparse import read_gtf
import pandas as pd
import os,sys,shutil

import seaborn as sb
import matplotlib.pyplot as plt

data_dir = '/Users/ernestomanuell/Desktop/Materias maestría/Dissertation Project'
directory="Enh vs EnhPr"
EnhEnhPr1_df=pd.read_csv(data_dir+'/'+directory+'/'+'TopWeights_Enh_vs_EnhPr_11.5.csv',sep='\t')
EnhEnhPr2_df=pd.read_csv(data_dir+'/'+directory+'/'+'FeatureWeightsPos&Neg_Enh_vs_EnhPr_12.5.csv',sep='\t')
EnhEnhPr3_df=pd.read_csv(data_dir+'/'+directory+'/'+'FeatureWeightsPos&Neg_Enh_vs_EnhPr_13.5.csv',sep='\t')


EnhEnhPr=pd.merge(EnhEnhPr1_df,EnhEnhPr2_df, on=['Feature'], how="inner")
EnhEnhPr.columns=['Feature','Weights_11.5',"Weights_12.5"]
EnhEnhPr_final=pd.merge(EnhEnhPr,EnhEnhPr3_df, on=['Feature'], how="inner")
EnhEnhPr_final.columns=['Features','Day11.5',"Day12.5","Day13.5"]
EnhEnhPr_heatmap=EnhEnhPr_final.set_index("Features")

EnhEnhPr_rna=EnhEnhPr_final["Features"]
RNA_EnhEnhPr=EnhEnhPr_rna.str.split(pat="_",n=1,expand=True)
RNA_EnhEnhPr.columns=["Motif","Rest"]

##Getting EnsembleID for Enh_EnhPr

import sys
import mygene
import re

mg = mygene.MyGeneInfo()

enhenhprlist=RNA_EnhEnhPr["Motif"].tolist()


genenames=open("Enh-EnhPrEnsemblIDsALL30.txt","a+")

for name in enhenhprlist:
    result = mg.query(name, scopes="symbol", fields=["ensembl.gene"], species="mouse", verbose=True)
    symbol = name
    for index,hit in enumerate(result['hits']):
        if index==0:
            if 'ensembl' in hit:
                s=str(hit['ensembl'])
                pattern="{'gene': '(.*)'}"
                search=re.search(pattern,s).group(1)
                genenames.write("%s\t%s\n" % (symbol, search))
genenames.close()


data_dir = '/Users/ernestomanuell/Desktop/Materias maestría/Dissertation Project'
day1RNA_df = pd.read_csv("ENCFF042VCB.tsv",sep='\t')
day2RNA_df = pd.read_csv("ENCFF649WEQ.tsv",sep='\t')
day3RNA_df = pd.read_csv("ENCFF794PWS.tsv",sep='\t')

EnhEnhPrlist_df=pd.read_csv("Enh-EnhPrEnsemblIDsALL30.txt",sep='\t',header=None)
EnhEnhPrlist_df.columns=["Symbol","gene_id"]
EnhEnhPrlist_df

EnhEnhPrlist=EnhEnhPrlist_df["gene_id"].to_list()

geneID1complete=day1RNA_df["gene_id"].to_list()
geneID1ready=[]
for e in geneID1complete:
    geneID2_1=e.split(".")
    geneID1=geneID2_1[0]
    geneID1ready.append(geneID1)
geneID1ready
day1RNA_df['gene_id']=geneID1ready

geneID2complete=day2RNA_df["gene_id"].to_list()
geneID2ready=[]
for e in geneID2complete:
    geneID2_2=e.split(".")
    geneID2=geneID2_2[0]
    geneID2ready.append(geneID2)
geneID2ready
day2RNA_df['gene_id']=geneID2ready

geneID3complete=day3RNA_df["gene_id"].to_list()
geneID3ready=[]
for e in geneID3complete:
    geneID3_2=e.split(".")
    geneID3=geneID3_2[0]
    geneID3ready.append(geneID3)
geneID3ready
day3RNA_df['gene_id']=geneID3ready

transcEnhEnhPrDay1_df=day1RNA_df[day1RNA_df['gene_id'].isin(EnhEnhPrlist)]
transcEnhEnhPrDay2_df=day2RNA_df[day2RNA_df['gene_id'].isin(EnhEnhPrlist)]
transcEnhEnhPrDay3_df=day3RNA_df[day3RNA_df['gene_id'].isin(EnhEnhPrlist)]

FinalTransEnhDay1_df=pd.merge(EnhEnhPrlist_df,transcEnhEnhPrDay1_df, on="gene_id", how="right")
EnhTrans1TF_df=FinalTransEnhDay1_df.loc[:,['Symbol','TPM']]

FinalTransEnhDay2_df=pd.merge(EnhEnhPrlist_df,transcEnhEnhPrDay2_df, on="gene_id", how="right")
EnhTrans2TF_df=FinalTransEnhDay2_df.loc[:,['Symbol','TPM']]

FinalTransEnhDay3_df=pd.merge(EnhEnhPrlist_df,transcEnhEnhPrDay3_df, on="gene_id", how="right")
EnhTrans3TF_df=FinalTransEnhDay3_df.loc[:,['Symbol','TPM']]

EnhEnhPrRNA_almost=pd.merge(EnhTrans1TF_df,EnhTrans2TF_df, on="Symbol", how="inner")
EnhEnhPrRNA_almost.columns=['Symbol','Weights_11.5',"Weights_12.5"]
EnhEnhPr_final=pd.merge(EnhEnhPrRNA_almost,EnhTrans3TF_df, on='Symbol', how="inner")
EnhEnhPr_final.columns=['Transcription Factor','Day11.5',"Day12.5","Day13.5"]

EnhEnhPr_final1=EnhEnhPr_final.drop_duplicates(ignore_index=True)
EnhEnhPr_final2=EnhEnhPr_final1.reindex([0,1,2,4,5,6,6,7,8,9,10,11,3,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28])
EnhEnhPr_final2

EnhEnhPr_final_heatmap=EnhEnhPr_final2.set_index("Transcription Factor")

fig, ax = plt.subplots(figsize=(11, 9))
sb.set_palette("Blues")
y=sb.heatmap(EnhEnhPr_final_heatmap, cmap="Blues", annot=True,fmt=".2f", cbar_kws={'label': 'TPM'})
y.set_yticklabels(y.get_yticklabels(), rotation=0)
plt.show()

#plt.figure(figsize=(20,10))
fig,(ax1,ax2)= plt.subplots(nrows=1, ncols=2, figsize=(20, 10))
#fig.suptitle("Top Features Analysis across developmental Days for Enh and EnhPr",fontsize=14,fontweight='bold')

#plt.subplot(1,2,1) # first heatmap
#ax1=sb.set_palette("Blues")
ax1=sb.heatmap(EnhEnhPr_heatmap, annot=True, cmap="coolwarm", center=0, cbar_kws={'label': 'Weights'},linewidths = 1, ax=ax1)
#ax1.set_title("Change in Weights",fontsize=14,fontweight='bold')
plt.text(0.5, 1.08, "Weights",
         horizontalalignment='center',
         fontsize=14, fontweight='bold', fontname="Arial",
         transform = ax1.transAxes)

#plt.subplot(1,2,2) # second heatmap
#ax2=sb.set_palette("Blues")
ax2=sb.heatmap(EnhEnhPr_final_heatmap, cmap="coolwarm", center=-5, annot=True,fmt=".2f", cbar_kws={'label': 'TPM'},linewidths = 1,ax=ax2)
ax2.set_yticklabels(y.get_yticklabels(), rotation=0)
#ax2.set_title("Change in TPM",fontsize=14,fontweight='bold')
plt.text(0.5, 1.08, "TPM",
         horizontalalignment='center',
         fontsize=14, fontweight='bold', fontname="Arial",
         transform = ax2.transAxes)

plt.show()


