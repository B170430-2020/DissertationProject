
#!/usr/bin/python3


##Works for WITH/WITHOUT ATAC (MFS/AcS modalities). Script for example pair Enh-Silent and feature set with ATAC
import numpy as np
import pandas as pd
import math
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split  ##To split data in training and test 
from sklearn import metrics
from sklearn.metrics import roc_auc_score
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler  ##to standardise data
from sklearn.model_selection import RandomizedSearchCV
from sklearn.linear_model import LogisticRegressionCV
import scikitplot as skplt   ##to build plots
from sklearn.manifold import TSNE  ##dimensionality reduction
import seaborn as sns

## set paths and filenames ##

# general data directory (where I have put the matrices)
data_dir = '/Users/ernestomanuell/Desktop/Materias maestría/Dissertation Project'

## directory for matrices
matrix_dir = data_dir + '/' + 'matrices'

state1='Enh'
state0='ReprPC,Quies,Het'
trainingday='11.5'
testday1='12.5'
testday2='13.5'

## training Matrices filenames
file1Train = 'Matrixfor_'+state1+'_'+trainingday+'_withATAC.tsv'  #'Matrixfor_Enh_11.5.tsv'
file0Train='Matrixfor_'+state0+'_'+trainingday+'_withATAC.tsv'  #'Matrixfor_Silent_11.5.tsv'

## testing Matrices Day 12.5 filenames
file1Test = 'Matrixfor_'+state1+'_'+testday1+'_withATAC.tsv'   #'Matrixfor_Enh_12.5.tsv'
file0Test='Matrixfor_'+state0+'_'+testday1+'_withATAC.tsv' #'Matrixfor_Silent_12.5.tsv'

## testing Matrices Day 13.5 filenames
file1Test2 = 'Matrixfor_'+state1+'_'+testday2+'_withATAC.tsv' #'Matrixfor_Enh_13.5.tsv'
file0Test2='Matrixfor_'+state0+'_'+testday2+'_withATAC.tsv' #'Matrixfor_Silent_13.5.tsv'

##Training dataset
featmat1Train_df = pd.read_csv(matrix_dir+'/'+file1Train,header=None,sep='\t')
featmat0Train_df = pd.read_csv(matrix_dir+'/'+file0Train,header=None,sep='\t')

##Testing dataset 1
featmat1Test_df = pd.read_csv(matrix_dir+'/'+file1Test,header=None,sep='\t')
featmat0Test_df = pd.read_csv(matrix_dir+'/'+file0Test,header=None,sep='\t')

##Testing dataset 2
featmat1Test2_df = pd.read_csv(matrix_dir+'/'+file1Test2,header=None,sep='\t')
featmat0Test2_df = pd.read_csv(matrix_dir+'/'+file0Test2,header=None,sep='\t')

##Training dataset
featmat1Train_df=featmat1Train_df.iloc[1:,1:]
featmat0Train_df=featmat0Train_df.iloc[1:,1:]

##Testing dataset
featmat1Test_df =featmat1Test_df.iloc[1:,1:]
featmat0Test_df=featmat0Test_df.iloc[1:,1:]

##Testing dataset 2
featmat1Test2_df =featmat1Test2_df.iloc[1:,1:]
featmat0Test2_df=featmat0Test2_df.iloc[1:,1:]

X_train=pd.concat([featmat1Train_df,featmat0Train_df])
len(X_train)

##Testing dataset 12.5
X_test=pd.concat([featmat1Test_df,featmat0Test_df])
len(X_test)

##Testing dataset 13.5
X_test2=pd.concat([featmat1Test2_df,featmat0Test2_df])
len(X_test2)

##Y variable has to be as long as the "samples" in this case peaks in each dataset (the number of rows).
#The column headers or motifs are the "features".
x1=np.ones(len(featmat1Train_df)) ##Enh
y1=np.zeros(len(featmat0Train_df)) ##Silent
y_train=np.hstack([x1,y1])
len(y_train)

##Clasification for day 12.5
x2=np.ones(len(featmat1Test_df))  #Enh
y2=np.zeros(len(featmat0Test_df)) ##Silent
y_test=np.hstack([x2,y2])
len(y_test)

##Clasification for day 13.5
x3=np.ones(len(featmat1Test2_df))  #Enh
y3=np.zeros(len(featmat0Test2_df)) ##Silent
y_test2=np.hstack([x3,y3])
len(y_test2)

##Fit on TRAINING data
scaler = StandardScaler()
scaler.fit(X_train)

##Standardise both training and testing independent values (samples)
X_train_stand=scaler.transform(X_train)
X_test_stand=scaler.transform(X_test)
X_test2_stand=scaler.transform(X_test2)

##Fit CV logreg into the standardised training dataset
c=[1E-7, 1E-6, 1E-6, 1E-4, 1E-3,1E-2,1E-1,1]
logreg = LogisticRegressionCV(cv=5, random_state=42,penalty='l1',solver='liblinear', scoring='balanced_accuracy',class_weight='balanced', max_iter=2000)

logreg.fit(X_train_stand, y_train)

print (logreg.C_)
print (logreg.intercept_)
print (logreg.coef_)

##Motif importance
#######This was done with only MFS feature sets.########################################
header_df = pd.read_csv(matrix_dir+'/'+file1Train,header=None,sep='\t')
headers=header_df.iloc[0,1:]
head=headers.to_numpy()

w=logreg.coef_[0]
feat_imp=pd.DataFrame(head,columns=["Feature"])
feat_imp["Weights"]=w
feat_imp=feat_imp.sort_values(by=["Weights"], ascending=False)
importancename="FeatureWeightsPos&Neg_"+state1+"_vs_"+state0+"_"+trainingday+".csv"
feat_imp.to_csv(importancename,index=False,sep='\t')
a=feat_imp.plot.barh(x="Feature",y="Weights", figsize=(20,18))

top=feat_imp.iloc[0:15,:]
bottom=feat_imp.tail(15)
topimp=pd.concat([top,bottom])
topname="TopWeights_"+state1+"_vs_"+state0+"_"+trainingday+".csv"
topimp.to_csv(topname,index=False,sep='\t')
plt.figure(figsize=(10, 8))
plt.barh(top['Feature'], top['Weights'], label='Positive')
plt.barh(bottom['Feature'], bottom['Weights'],label='Negative')
plt.title("Top 15 positive and 15 negative weighted features for the Enh-Silent model")
plt.xlabel("Weights")
plt.xlim([-0.2,0.6])
plt.ylabel("Features")
plt.show()

##Features that contribute most to the model (both neg and pos). 
w1=abs(logreg.coef_[0])
feat_imp1=pd.DataFrame(head,columns=["Feature"])
feat_imp1["Importance"]=100.0 * (w1 / w1.max())
feat_imp1=feat_imp1.sort_values(by=["Importance"], ascending=False)
importancename1="FeatureImportances_"+state1+"_vs_"+state0+"_"+trainingday+".csv"
feat_imp1.to_csv(importancename1,index=False,sep='\t')
a=feat_imp1.plot.barh(x="Feature",y="Importance", figsize=(20,18))

top1=feat_imp1.iloc[0:30,:]
bottom1=feat_imp1.tail(10)
topimp1=pd.concat([top1,bottom1])
topname1="TopImportances_"+state1+"_vs_"+state0+"_"+trainingday+".csv"
topimp1.to_csv(topname1,index=False,sep='\t')

plt.figure(figsize=(10,8))
plt.barh(top1['Feature'], top1['Importance'], color='m')
plt.title("30 most important features for the Enh-Silent model")
plt.xlabel("Importance(%)")
plt.ylabel("Feature")
plt.show()

#######################################################################################
##Again for with/without ATAC feature sets.
##Metrics for training data (11.5)
y_pred=logreg.predict(X_train_stand)
from sklearn.metrics import classification_report

print(classification_report(y_train, y_pred))

##Metrics for test day 12.5
y_pred_test=logreg.predict(X_test_stand)
from sklearn.metrics import classification_report

print(classification_report(y_test, y_pred_test))

##Metrics for test day 13.5
y_pred_test2=logreg.predict(X_test2_stand)
from sklearn.metrics import classification_report

print(classification_report(y_test2, y_pred_test2))

##Confusion matrices
cm=metrics.confusion_matrix(y_test,y_pred_test)
print (cm)

cm2=metrics.confusion_matrix(y_test2,y_pred_test2)
print (cm2)

#Probability Histograms
prob=logreg.predict_proba(X_train_stand)
prob_test=logreg.predict_proba(X_test_stand)
prob_test2=logreg.predict_proba(X_test2_stand)

f=plt.figure(figsize=(6,12))
#f.subplots_adjust(hspace=0.6, wspace=0.5)

f.suptitle("Probability Histograms for Enh and Silent",fontsize=14,fontweight='bold')
f.subplots_adjust(left=0.15, top=0.93,hspace=0.3, wspace=0.3)

plt.subplot(3,1,1)
enh=prob[:,1] ##Peaks in Training Day 11.5
plt.hist(enh[y_train==0],50,range=(0,1), density=True, color="indigo", label="Silent", alpha=0.5)  ##Peaks that are actually Silent
plt.hist(enh[y_train==1],50,range=(0,1), density=True, color="c", label="Enh", alpha=0.6) ##Peaks that are actually Enh
plt.xlabel('p(peak=Enh)')
plt.ylabel('Density')
plt.title("Peaks annotated as Enh and Silent for Training Day 11.5")
plt.legend()

plt.subplot(3,1,2)
enh_test=prob_test[:,1]  ##Peaks in Test Day 12.5
plt.hist(enh_test[y_test==0],50,range=(0,1), density=True, color="indigo", label="Silent", alpha=0.5)
plt.hist(enh_test[y_test==1],50,range=(0,1), density=True, color="darkorange", label="Enh", alpha=0.6)
plt.xlabel('p(peak=Enh)')
plt.ylabel('Density')
plt.title("Peaks annotated as Enh and Silent for Test Day 12.5")
plt.legend()

plt.subplot(3,1,3)
enh_test2=prob_test2[:,1]  ##Peaks in Test Day 13.5
plt.hist(enh_test2[y_test2==0],50,range=(0,1), density=True, color="indigo", label="Silent", alpha=0.5)
plt.hist(enh_test2[y_test2==1],50,range=(0,1),density=True, color="limegreen", label="Enh", alpha=0.6)
plt.xlabel('p(peak=Enh)')
plt.ylabel('Density')
plt.title("Peaks annotated as Enh and Silent for Test Day 13.5")
plt.legend()

plt.show()

##Boundary threshold analysis
from sklearn.metrics import precision_recall_curve
y_true = y_train
y_scores = prob[:,1]
precision, recall, thresholds = precision_recall_curve(
    y_true, y_scores)

from sklearn.metrics import PrecisionRecallDisplay
disp=PrecisionRecallDisplay(precision=precision,recall=recall)
disp.plot()

def f1score(precision, recall):
    return 2 * (precision * recall)/(precision + recall)

thresholds[f1score(precision, recall).argmax()]

f1score(precision, recall).max()

##ROC AUC scores

##ROC curve for day 12.5
probtest=logreg.predict_proba(X_test_stand)

print(roc_auc_score(y_test, probtest[:,1]))
skplt.metrics.plot_roc(
 y_test, probtest, title="Roc Curve",
 figsize=(10, 8))
##ROC curve for day 13.5
probtest2=logreg.predict_proba(X_test2_stand)

print(roc_auc_score(y_test2, probtest2[:,1]))
skplt.metrics.plot_roc(
 y_test2, probtest2, title="Roc Curve",
 figsize=(10, 8))

##tSNE visualisations

data_pca1 = PCA(n_components=10,random_state=42).fit_transform(X_train_stand)
data_pca2 = PCA(n_components=10,random_state=42).fit_transform(X_test_stand)
data_pca3 = PCA(n_components=10,random_state=42).fit_transform(X_test2_stand)
data_tsne1=TSNE(n_components=2,random_state=42).fit_transform(data_pca1)
data_tsne2=TSNE(n_components=2,random_state=42).fit_transform(data_pca2)
data_tsne3=TSNE(n_components=2,random_state=42).fit_transform(data_pca3)

##For training dataset
positive_tsne, positive_labels=zip(*[(tsne,y)for tsne,y in zip (data_tsne1, y_train) if y==1])
negative_tsne, negative_labels=zip(*[(tsne,y)for tsne,y in zip (data_tsne1, y_train) if y==0])
positive_tsne=np.array(positive_tsne)
negative_tsne=np.array(negative_tsne)

positive_tsne_pred, positive_labels_pred=zip(*[(tsne,y)for tsne,y in zip (data_tsne1, y_pred) if y==1])
negative_tsne_pred, negative_labels_pred=zip(*[(tsne,y)for tsne,y in zip (data_tsne1, y_pred) if y==0])
positive_tsne_pred=np.array(positive_tsne_pred)
negative_tsne_pred=np.array(negative_tsne_pred)

##For test dataset 1
positive_tsne2, positive_labels2=zip(*[(tsne,y)for tsne,y in zip (data_tsne2, y_test) if y==1])
negative_tsne2, negative_labels2=zip(*[(tsne,y)for tsne,y in zip (data_tsne2, y_test) if y==0])
positive_tsne2=np.array(positive_tsne2)
negative_tsne2=np.array(negative_tsne2)

positive_tsne2_pred, positive_labels2_pred=zip(*[(tsne,y)for tsne,y in zip (data_tsne2, y_pred_test) if y==1])
negative_tsne2_pred, negative_labels2_pred=zip(*[(tsne,y)for tsne,y in zip (data_tsne2, y_pred_test) if y==0])
positive_tsne2_pred=np.array(positive_tsne2_pred)
negative_tsne2_pred=np.array(negative_tsne2_pred)

##For test dataset 2
positive_tsne3, positive_labels3=zip(*[(tsne,y)for tsne,y in zip (data_tsne3, y_test2) if y==1])
negative_tsne3, negative_labels3=zip(*[(tsne,y)for tsne,y in zip (data_tsne3, y_test2) if y==0])
positive_tsne3=np.array(positive_tsne3)
negative_tsne3=np.array(negative_tsne3)

positive_tsne3_pred, positive_labels3_pred=zip(*[(tsne,y)for tsne,y in zip (data_tsne3, y_pred_test2) if y==1])
negative_tsne3_pred, negative_labels3_pred=zip(*[(tsne,y)for tsne,y in zip (data_tsne3, y_pred_test2) if y==0])
positive_tsne3_pred=np.array(positive_tsne3_pred)
negative_tsne3_pred=np.array(negative_tsne3_pred)

from matplotlib.transforms import offset_copy


cols = ['True Labels', 'Predicted Labels']
rows = ['Training Day 11.5','Test Day 12.5','Test Day 13.5']


fig, axes = plt.subplots(nrows=3, ncols=2, figsize=(12, 12))
plt.setp(axes.flat, xlabel='tSNE-1', ylabel='tSNE-2')
fig.suptitle("tSNE Plots of true and predicted Labels for Enh and Silent",fontsize=14,fontweight='bold')
fig.subplots_adjust(left=0.15, top=0.93,hspace=0.3, wspace=0.3)

pad = 7 # in points

for ax, col in zip(axes[0], cols):
    ax.annotate(col, xy=(0.5, 1), xytext=(0, pad),
                xycoords='axes fraction', textcoords='offset points',
                size='large', ha='center', va='center')

for ax, row in zip(axes[:,0], rows):
    ax.annotate(row, xy=(0, 0.5), xytext=(-ax.yaxis.labelpad - pad, 0),
                xycoords=ax.yaxis.label, textcoords='offset points',
                size='large', ha='right', va='center')

axes[0,0].scatter(negative_tsne[:,0],negative_tsne[:,1],s=6, c=negative_labels, label="Silent",alpha=0.7)
axes[0,0].scatter(positive_tsne[:,0],positive_tsne[:,1],s=6, c="c",label="Enh", alpha=0.2)
axes[0,0].set_xlim([-80,80])
#axes[0,0].set_ylim([-70,80])
axes[0,0].legend(loc='upper right',frameon=False, markerscale=3,handletextpad=0.1)

axes[0,1].scatter(negative_tsne_pred[:,0],negative_tsne_pred[:,1],s=6, c=negative_labels_pred, label="Silent", alpha=0.7)
axes[0,1].scatter(positive_tsne_pred[:,0],positive_tsne_pred[:,1],s=6, c="c",label="Enh", alpha=0.2)
axes[0,1].set_xlim([-80,80])
#axes[0,1].set_ylim([-70,80])
axes[0,1].legend(loc='upper right',frameon=False, markerscale=3,handletextpad=0.1)

axes[1,0].scatter(negative_tsne2[:,0],negative_tsne2[:,1],s=6,c=negative_labels2,label="Silent", alpha=0.7)
axes[1,0].scatter(positive_tsne2[:,0],positive_tsne2[:,1],s=6,c="darkorange", label="Enh", alpha=0.2)
axes[1,0].set_xlim([-80,80])
#axes[1,0].set_ylim([-70,80])
axes[1,0].legend(loc='upper right',frameon=False, markerscale=3,handletextpad=0.1)

axes[1,1].scatter(negative_tsne2_pred[:,0],negative_tsne2_pred[:,1],s=6, c=negative_labels2_pred, label="Silent", alpha=0.5)
axes[1,1].scatter(positive_tsne2_pred[:,0],positive_tsne2_pred[:,1],s=6,c="darkorange", label="Enh", alpha=0.2)
axes[1,1].set_xlim([-80,80])
#axes[1,1].set_ylim([-70,80])
axes[1,1].legend(loc='upper right',frameon=False, markerscale=3,handletextpad=0.1)

axes[2,0].scatter(negative_tsne3[:,0],negative_tsne3[:,1],s=6, c=negative_labels3,label="Silent", alpha=0.7)
axes[2,0].scatter(positive_tsne3[:,0],positive_tsne3[:,1],s=6, c="limegreen",label="Enh", alpha=0.2)
axes[2,0].set_xlim([-80,80])
#axes[2,0].set_ylim([-70,80])
axes[2,0].legend(loc='upper right',frameon=False, markerscale=3,handletextpad=0.1)

axes[2,1].scatter(negative_tsne3_pred[:,0],negative_tsne3_pred[:,1],s=6, c=negative_labels3_pred,label="Silent", alpha=0.7)
axes[2,1].scatter(positive_tsne3_pred[:,0],positive_tsne3_pred[:,1],s=6, c="limegreen", label="Enh", alpha=0.2)
axes[2,1].set_xlim([-80,80])
#axes[2,1].set_ylim([-70,80])
axes[2,1].legend(loc='upper right',frameon=False, markerscale=3, handletextpad=0.1)

plt.show()



