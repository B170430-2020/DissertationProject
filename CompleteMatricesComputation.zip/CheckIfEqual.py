#!/usr/bin/python3

import os, sys, subprocess, shutil, pandas as pd, numpy as np

df=pd.read_csv("FeatureMatrix_11.5.tsv", sep='\t')
df2=pd.read_csv("FeatureMatrix_11.5_FAST.tsv", sep='\t')
print(df.equals(df2))

df3=pd.read_csv("FeatureMatrix_12.5.tsv", sep='\t')
df4=pd.read_csv("FeatureMatrix_12.5_FAST.tsv", sep='\t')
print(df3.equals(df4))

df5=pd.read_csv("FeatureMatrix_12.5.tsv", sep='\t')
df6=pd.read_csv("FeatureMatrix_12.5_FAST.tsv", sep='\t')
print(df5.equals(df6))