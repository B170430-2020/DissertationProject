#!/usr/bin/python3

import os, sys, subprocess, shutil, pandas as pd, numpy as np

peak_coord_df=pd.read_csv('Enhancerpeaks_for_TOBIAS.bed', header=None, sep='\t')
header= ['chrom', 'chromStart', 'chromEnd', 'Annotation_11.5','Annotation_12.5','Annotation_13.5']
peak_coord_df.columns = header[:len(peak_coord_df.columns)]
peak_coord_df['id']='peak-'+peak_coord_df.index.astype(str)

npeaks=peak_coord_df.shape[0]
print('Number of peaks: ', npeaks)
print(peak_coord_df)

annotation=input('Annotation(s) to keep separated by comma: ').rstrip()
annotation_list=annotation.split(",")
selection= peak_coord_df['Annotation_11.5'].isin(annotation_list)
selection_df=peak_coord_df[selection]

##For training day 11.5 
peakchange1_df=selection_df.loc[selection_df['Annotation_11.5']==selection_df['Annotation_12.5']]
peakchange1_df.rename(columns={'id': 'peak-id'}, inplace=True)
print(peakchange1_df)
peakchange1_df.to_csv("Peaks_SAME_"+annotation+"_Day11.5_Day12.5.tsv",index=False , sep='\t')
peakchange1_df['peak-id'].to_csv("PeakIDs_"+annotation+"_SAME_Day11.5_Day12.5.tsv", sep='\t')

peakchange2_df=selection_df.loc[selection_df['Annotation_11.5']==selection_df['Annotation_13.5']]
peakchange2_df.rename(columns={'id': 'peak-id'}, inplace=True)
print(peakchange2_df)
peakchange2_df.to_csv("Peaks_SAME_"+annotation+"_Day11.5_Day13.5.tsv",index=False , sep='\t')
peakchange2_df['peak-id'].to_csv("PeakIDs_"+annotation+"_SAME_Day11.5_Day13.5.tsv", sep='\t')

