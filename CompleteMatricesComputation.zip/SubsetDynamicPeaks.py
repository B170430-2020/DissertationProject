#!/usr/bin/python3

import os, sys, subprocess, shutil, pandas as pd, numpy as np

peak_coord_df=pd.read_csv('Enhancerpeaks_for_TOBIAS.bed', header=None, sep='\t')
header= ['chrom', 'chromStart', 'chromEnd', 'Annotation_11.5','Annotation_12.5','Annotation_13.5']
peak_coord_df.columns = header[:len(peak_coord_df.columns)]
peak_coord_df['id']='peak-'+peak_coord_df.index.astype(str)

npeaks=peak_coord_df.shape[0]
print('Number of peaks: ', npeaks)
print(peak_coord_df)

annotation=input('Annotation(s) to keep separated by comma: ').rstrip()
annotation_list=annotation.split(",")
selection= peak_coord_df['Annotation_11.5'].isin(annotation_list)
selection_df=peak_coord_df[selection]

##For training day 11.5 
peakchange1_df=selection_df.loc[selection_df['Annotation_11.5']!=selection_df['Annotation_12.5']]
peakchange1_df.rename(columns={'id': 'peak-id'}, inplace=True)
print(peakchange1_df)
peakchange1_df.to_csv("Peaks_Change_"+annotation+"_Day11.5_Day12.5.tsv",index=False , sep='\t')
peakchange1_df['peak-id'].to_csv("PeakIDs_"+annotation+"_Change_Day11.5_Day12.5.tsv", sep='\t')

peakchange2_df=selection_df.loc[selection_df['Annotation_11.5']!=selection_df['Annotation_13.5']]
peakchange2_df.rename(columns={'id': 'peak-id'}, inplace=True)
print(peakchange2_df)
peakchange2_df.to_csv("Peaks_Change_"+annotation+"_Day11.5_Day13.5.tsv",index=False , sep='\t')
peakchange2_df['peak-id'].to_csv("PeakIDs_"+annotation+"_Change_Day11.5_Day13.5.tsv", sep='\t')


'''
##Training Day 12.5
selection2= peak_coord_df['Annotation_12.5'].isin(annotation_list)
selection2_df=peak_coord_df[selection2]
peakchange3_df=selection2_df.loc[selection2_df['Annotation_12.5']!=selection2_df['Annotation_11.5']]
peakchange3_df.rename(columns={'id': 'peak-id'}, inplace=True)
print(peakchange3_df)
peakchange3_df.to_csv("Peaks_Change_"+annotation+"_Day12.5_Day11.5.tsv",index=False , sep='\t')
peakchange3_df['peak-id'].to_csv("PeakIDs_"+annotation+"_Change_Day12.5_Day11.5.tsv", sep='\t')

peakchange4_df=selection2_df.loc[selection2_df['Annotation_12.5']!=selection2_df['Annotation_13.5']]
peakchange4_df.rename(columns={'id': 'peak-id'}, inplace=True)
print(peakchange4_df)
peakchange4_df.to_csv("Peaks_Change_"+annotation+"_Day12.5_Day13.5.tsv",index=False , sep='\t')
peakchange4_df['peak-id'].to_csv("PeakIDs_"+annotation+"_Change_Day12.5_Day13.5.tsv", sep='\t')

##Training Day 13.5
selection3= peak_coord_df['Annotation_13.5'].isin(annotation_list)
selection3_df=peak_coord_df[selection3]
peakchange5_df=selection3_df.loc[selection3_df['Annotation_13.5']!=selection3_df['Annotation_11.5']]
peakchange5_df.rename(columns={'id': 'peak-id'}, inplace=True)
print(peakchange5_df)
peakchange5_df.to_csv("Peaks_Change_"+annotation+"_Day13.5_Day11.5.tsv",index=False , sep='\t')
peakchange5_df['peak-id'].to_csv("PeakIDs_"+annotation+"_Change_Day13.5_Day11.5.tsv", sep='\t')

selection3= peak_coord_df['Annotation_13.5'].isin(annotation_list)
selection3_df=peak_coord_df[selection3]
peakchange6_df=selection3_df.loc[selection3_df['Annotation_13.5']!=selection3_df['Annotation_12.5']]
peakchange6_df.rename(columns={'id': 'peak-id'}, inplace=True)
print(peakchange6_df)
peakchange6_df.to_csv("Peaks_Change_"+annotation+"_Day13.5_Day12.5.tsv",index=False , sep='\t')
peakchange6_df['peak-id'].to_csv("PeakIDs_"+annotation+"_Change_Day13.5_Day12.5.tsv", sep='\t')
'''