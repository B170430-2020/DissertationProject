
#!/usr/bin/python3

import os, sys, subprocess, shutil, pandas as pd, numpy as np

from os import listdir
from os.path import isfile, join

##Create file with xlsx for each motif
os.makedirs('motif_results', exist_ok=True)
pathname=os.getcwd()
#move each xlsx to the file
for directory in os.listdir("."):     #going through every file in the actual directory
  if directory.endswith(".1"):
    srcdir=os.path.join(pathname,directory)
    for filename in os.listdir(srcdir):
      if filename.endswith('.xlsx'):
        inpath=os.path.join(srcdir,filename)
        if os.path.isfile(inpath):
          finaldirec=pathname+'/'+'motif_results'
          shutil.copy(inpath, finaldirec)

shutil.copy('../Enhancerpeaks_for_TOBIAS.bed', '.')

##delete columns from Enhancer peaks for TOBIAS and save it as a new bed file
peakcoor=pd.read_csv('Enhancerpeaks_for_TOBIAS.bed', header=None, sep='\t')
header= ['chrom', 'chromStart', 'chromEnd', 'Annotation_11.5','Annotation_12.5','Annotation_13.5']
peakcoor.columns = header[:len(peakcoor.columns)]

del peakcoor['Annotation_11.5']
del peakcoor['Annotation_12.5']
del peakcoor['Annotation_13.5']
peakcoor.to_csv("Enhancerpeaks_ForMatrices.bed", header=False, index=False , sep='\t')

##
motif_dir=pathname+'/'+ 'motif_results'
peak_coordinates_file="Enhancerpeaks_ForMatrices.bed"

peak_coord_header=['chrom','chromStart','chromEnd']
peak_coord_df=pd.read_csv(pathname+'/'+peak_coordinates_file,names=peak_coord_header, sep='\t')
peak_coord_df['id']='peak-'+peak_coord_df.index.astype(str)

npeaks=peak_coord_df.shape[0]
print('Number of peaks: ', npeaks)
peak_coord_df

## create a list of motif files ## 
motif_files = [f for f in listdir(motif_dir) if isfile(join(motif_dir, f))]
motif_files = sorted(motif_files)
print(motif_files)

## create a 'master' dataframe containing results from all motif files       ## 
## this reads each .xlsx file as a dataframe and appends it to the master df ##

tobias_footprint_df = pd.read_excel(motif_dir+'/'+ motif_files[0], sheet_name='Sheet1')

for file in motif_files[1:]:
    
    tobias_footprint_df = tobias_footprint_df.append(pd.read_excel(motif_dir+'/'+file, sheet_name='Sheet1'),
                                                     ignore_index=True)

def create_feature_matrix_from_tobias_results(tobias_df, day_string, peak_coord_df):
    """
    Function to turn tobias footprint dataframe into a feature matrix (npeaks x nmotifs)
    
    Inputs:
    -- tobias_df: dataframe of merged tobias BINDetect results (all motifs)
    -- day_string: which footprint results to create feature matrix for, e.g. 'Day2_footprints_score'
    -- peak_coord_df: dataframe containing peak coordinates of consensus peaks
    
    Note: this function will only work if the column names in both input dataframes match those
          used in the code below ... if these change, the code will have to be adapted.
    """
    print('Creating feature matrix for:', day_string)
    
    ## 1. if multiple motifs found in a peak, group these, taking maximum ##
    print('1. grouping scores (if > 1 motif score in a peak)')
    tobias_day_scores_df = tobias_df.groupby(['peak_chr','peak_start','peak_end','TFBS_name']).agg({day_string: ['max']})
    tobias_day_scores_df.columns = [day_string]

    tobias_day_scores_df = tobias_day_scores_df.reset_index()

    
    ## 2. for each row in footprint dataframe, find appropriate 'peak-id' ##
    ## Note: this step might take a little time, particularly if you      ##
    ##       have many motifs                                             ##
    print('2. adding appropriate peak-ids to motif-scores (this may take a while)')
    
    tmp_peak_ids = []
    for k in range(tobias_day_scores_df.shape[0]):

        tmp_chrom      = tobias_day_scores_df['peak_chr'].iloc[k]
        tmp_chromStart = tobias_day_scores_df['peak_start'].iloc[k]
        tmp_chromEnd   = tobias_day_scores_df['peak_end'].iloc[k]

        bool_peak_select = (peak_coord_df['chrom'] == tmp_chrom) & \
                           (peak_coord_df['chromStart'] == tmp_chromStart) & \
                           (peak_coord_df['chromEnd'] == tmp_chromEnd)

        tmp_peak_ids.append(peak_coord_df['id'][bool_peak_select].values[0])

    print(tobias_day_scores_df.shape[0], len(tmp_peak_ids))

    ## add the appropriate 'peak-id' to each row of the footprinting dataframe ##
    tobias_day_scores_df['peak-id'] = tmp_peak_ids
    
    
    # 3. unpack dataframe to a df resembling the feature matrix (peaks x motifs) we want
    print('3. first step of feature matrix')
    
    keep_cols = ['peak-id','TFBS_name',day_string]
    tmp_score_df = tobias_day_scores_df[keep_cols].pivot_table(index='peak-id',columns='TFBS_name',fill_value=0.)
    tmp_score_df = tmp_score_df.reset_index()
    tmp_score_df = tmp_score_df.rename(columns={"Index":'peak-id'})
    tmp_score_df.columns = tmp_score_df.columns.droplevel()
    tmp_score_df = tmp_score_df.rename(columns={'':'peak-id'})

    # 4. here we fill in the missing rows (peaks where no motifs were found)
    
    print('4. finalizing feature matrix')
    npeaks = peak_coord_df.shape[0]
    score_df =  pd.DataFrame(np.arange(npeaks)).rename(columns={0:'peak-id'})
    score_df['peak-id'] = 'peak-'+score_df['peak-id'].astype(str)
    score_df = pd.merge(score_df,tmp_score_df,on=['peak-id'],how='left')
    score_df = score_df.fillna(0)
    
    print('Done!')
    
    return score_df

tobias_day1_scores_df = create_feature_matrix_from_tobias_results(tobias_footprint_df, 'Day1_footprints_score', peak_coord_df)
tobias_day2_scores_df = create_feature_matrix_from_tobias_results(tobias_footprint_df, 'Day2_footprints_score', peak_coord_df)
tobias_day3_scores_df = create_feature_matrix_from_tobias_results(tobias_footprint_df, 'Day3_footprints_score', peak_coord_df)

tobias_day1_scores_df.to_csv("FeatureMatrix_11.5.tsv", index=False , sep='\t')
tobias_day2_scores_df.to_csv("FeatureMatrix_12.5.tsv", index=False , sep='\t')
tobias_day3_scores_df.to_csv("FeatureMatrix_13.5.tsv", index=False , sep='\t')
