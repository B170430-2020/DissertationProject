
##with ggalluvial
install.packages("ggalluvial")
remotes::install_github("corybrunson/ggalluvial@main", build_vignettes = TRUE)
remotes::install_github("corybrunson/ggalluvial", ref = "optimization")
library(ggplot2)
library(ggalluvial)
install.packages("ggsci")
library("ggsci")          

bed<- read.table("Enhancerpeaks_ToPlot_NoDot.bed", header=FALSE, sep="\t",stringsAsFactors=FALSE, quote="")
head(bed)
colnames(bed)<-c("chrom", "chromStart","chromEnd","E11.5","E12.5", "E13.5")
head(bed)
col_vector = c("mediumpurple", "maroon1", "turquoise", "navyblue",
               "orangered", "khaki1", "seagreen3", "palevioletred")
is_alluvia_form(as.data.frame(bed), axes = 4:6, silent = TRUE)

##THIS WORKS AND IS THE FINAL GRAPH with Y_label
ggplot(as.data.frame(bed), stat = "stratum",aes(axis1 = E11.5, axis2 = E12.5, axis3 = E13.5, 
                                                fill=after_stat(stratum))) +
  geom_flow(width = 1/12, lode.guidance = "frontback") +
  scale_x_discrete(limits = c("E11.5", "E12.5","E13.5"), expand = c(.05, .05))+
  scale_fill_manual(values = col_vector) +
  geom_stratum(alpha = .6, width = 1/12, stat = "stratum", aes(fill = after_stat(stratum))) +
  theme(legend.position = "bottom", panel.background = element_blank()) +
  ylab("Counts")+
  ggtitle("State transitions across embryonic days")


