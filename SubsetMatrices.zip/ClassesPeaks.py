
#!/usr/bin/python3

import os, sys, subprocess, shutil, pandas as pd

day=input('Day for Peaks: ').rstrip()
filename='Enhancerpeaks_ToPlot_NoDot.bed'
df=pd.read_csv(filename,header=None, sep='\t')
columnchosen='Annotation_'+day
header= ['chrom', 'chromStart', 'chromEnd', 'Annotation_11.5','Annotation_12.5','Annotation_13.5']
df.columns = header[:len(df.columns)]
print(df)
'''
df1=df.loc[df[columnchosen]=='Enh']
enhname="Peaks_ActEnhancers_"+day+".bed"
df1.to_csv(enhname, header=False, index=False , sep='\t')
'''

df5=df.loc[df[columnchosen]=='Quies']
enhname="Peaks_QuiesState_"+day+".bed"
df5.to_csv(enhname, header=False, index=False , sep='\t')

'''
df2=df.loc[df[columnchosen].isin(['EnhPr','EnhPois','Het', 'ReprPC','Tss','Tx','Quies'])]
nonactivename="Peaks_NonActiveStates_"+day+".bed"
df2.to_csv(nonactivename, header=False, index=False , sep='\t')

df3=df.loc[df[columnchosen].isin(['EnhPr','EnhPois'])]
almactname="Peaks_AlmActEnhancers_"+day+".bed"
df3.to_csv(almactname, header=False, index=False , sep='\t')

df4=df.loc[df[columnchosen].isin(['Het', 'ReprPC','Tss','Tx','Quies'])]
compnonname="Peaks_CompNonActiveRegions_"+day+".bed"
df4.to_csv(compnonname, header=False, index=False , sep='\t')
'''

