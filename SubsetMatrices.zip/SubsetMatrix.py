
#!/usr/bin/python3

import os, sys, subprocess, shutil, pandas as pd

##Subsetting feature matrix with desired states
day=input('Day for Peaks: ').rstrip()
annotation=input('Annotation(s) to keep separated by comma: ').rstrip()
annotation_list=annotation.split(",")
columnname='Annotation_'+day
peak_coordinates_file="Enhancerpeaks_ToPlot_NoDot.bed"

peak_coord_header=['chrom','chromStart','chromEnd','Annotation_11.5','Annotation_12.5','Annotation_13.5']
peak_coord_df=pd.read_csv(peak_coordinates_file,names=peak_coord_header, sep='\t')
peak_coord_df['id']='peak-'+peak_coord_df.index.astype(str)

if day=="11.5":
  del peak_coord_df['Annotation_12.5']
  del peak_coord_df['Annotation_13.5']
if day=="12.5":
  del peak_coord_df['Annotation_11.5']
  del peak_coord_df['Annotation_13.5']
if day=="13.5":
  del peak_coord_df['Annotation_11.5']
  del peak_coord_df['Annotation_12.5']

print(peak_coord_df)

selection= peak_coord_df[columnname].isin(annotation_list)
print(selection.head())

filename= 'FeatureMatrix_'+day+'_correct.tsv'
featmat_df=pd.read_csv(filename, sep='\t')
featmat_df=featmat_df[selection]
print(featmat_df)
finname='Matrixfor_'+annotation+'_'+day+'.tsv'
featmat_df.to_csv(finname, index=False , sep='\t')

