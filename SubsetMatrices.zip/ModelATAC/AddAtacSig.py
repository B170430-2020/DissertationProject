#!/usr/bin/python3

import os, sys, subprocess, shutil, pandas as pd, numpy as np

##chosing feature matrix and atac column with desired day
day=input('Day for Matrix&ATAC: ').rstrip()
matrixfile='FeatureMatrix_'+day+'_correct.tsv'
matrix_df=pd.read_csv(matrixfile,sep='\t')

atacfile='atacseq_11_12_13.csv'
atac_df=pd.read_csv(atacfile,sep='\t')
ataccolumn='atac-pval-signal-'+day
matrixcolumn='ATAC_'+day 
matrix_df[matrixcolumn]=atac_df[ataccolumn]

##Save feature matrix with added atac seq column
matrix_df.to_csv("FeatureMatrix_"+day+"_withATAC.tsv",index=False, sep='\t') 


