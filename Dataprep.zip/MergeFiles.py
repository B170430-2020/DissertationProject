
#!/usr/bin/python3

import os, sys, subprocess, shutil

##Removing header of files and merging them
merged=[]
times=open("Enhancer_3times_withIntrons.tsv","a+") 
for filename in os.listdir("."):     #going through every file in the actual directory
  if filename.endswith("withIntrons.tsv"):
    f=open(filename)   #open file to read every line
    for line in f:
       if "start" not in line:
         merged.append(line)

mergedstr="".join(merged)
times.write(mergedstr)
times.close()