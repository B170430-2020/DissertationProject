#!/usr/bin/python3

import os, sys, subprocess, shutil


filein=input("ENCODE filename: ").rstrip()
day=input("Day of development: ").rstrip()
filename=filein+"_"+day+"_peakannotation.tsv"
finalname=filein+"_"+day+"_enhancerpeaks_withIntrons.tsv"


subset="grep 'seqnames' {}>{}".format(filename, finalname)
subprocess.check_output(subset, shell=True)
subset1="grep 'Distal Intergenic' {}>>{}".format(filename, finalname)
subprocess.check_output(subset1, shell=True)
subset2="grep 'Intron' {}>>{}".format(filename, finalname)
subprocess.check_output(subset2, shell=True)




