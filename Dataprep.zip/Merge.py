
#!/usr/bin/python3

import os, sys, subprocess, shutil

#To merge the peaks for the three times
catcommand="cat Enhancer_3times_withIntrons.tsv> Enhancerpeaks_3times_withIntrons.bed"
subprocess.check_output(catcommand, shell=True)

sort="bedtools sort -i Enhancerpeaks_3times_withIntrons.bed>Enhancerpeaks_3times_withIntrons_sorted.bed"
subprocess.check_output(sort, shell=True)

merge="bedtools merge -i Enhancerpeaks_3times_withIntrons_sorted.bed> Enhancerpeaks_3times_merged.bed"
subprocess.check_output(merge, shell=True)