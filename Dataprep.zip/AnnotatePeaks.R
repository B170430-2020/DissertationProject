library(ChIPseeker)
library(TxDb.Mmusculus.UCSC.mm10.knownGene)
library(org.Mm.eg.db)
library(R.utils)


txdb <- TxDb.Mmusculus.UCSC.mm10.knownGene

#Download files day 11.5, 12.5, 13.5 in that order
system("wget https://www.encodeproject.org/files/ENCFF767MGH/@@download/ENCFF767MGH.bed.gz")
system("wget https://www.encodeproject.org/files/ENCFF316QPC/@@download/ENCFF316QPC.bed.gz")
system("wget https://www.encodeproject.org/files/ENCFF345CWR/@@download/ENCFF345CWR.bed.gz")

gunzip("ENCFF767MGH.bed.gz")
gunzip("ENCFF316QPC.bed.gz")
gunzip("ENCFF345CWR.bed.gz")

peak_file <- "ENCFF767MGH.bed"
peak_file1 <- "ENCFF316QPC.bed"
peak_file2 <- "ENCFF345CWR.bed"

peakAnno <- annotatePeak(peak_file, tssRegion=c(-1000, 500), TxDb=txdb, annoDb="org.Mm.eg.db")
peakAnno1<- annotatePeak(peak_file1, tssRegion=c(-1000, 500), TxDb=txdb, annoDb="org.Mm.eg.db")
peakAnno2 <- annotatePeak(peak_file2, tssRegion=c(-1000, 500), TxDb=txdb, annoDb="org.Mm.eg.db")

anno_df <- as.data.frame(peakAnno)
anno_df1 <- as.data.frame(peakAnno1)
anno_df2 <- as.data.frame(peakAnno2)

colnames(anno_df)

write.table(anno_df, file = "ENCFF767MGH_11.5_peakannotation.tsv", row.names = F, col.names = T, quote = F, sep = "\t")
write.table(anno_df1, file = "ENCFF316QPC_12.5_peakannotation.tsv", row.names = F, col.names = T, quote = F, sep = "\t")
write.table(anno_df2, file = "ENCFF345CWR_13.5_peakannotation.tsv", row.names = F, col.names = T, quote = F, sep = "\t")

