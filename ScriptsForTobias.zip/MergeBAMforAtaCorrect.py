
#!/usr/bin/python3

import os, sys, subprocess, shutil

#Download bam 1 day 1
os.system('wget https://www.encodeproject.org/files/ENCFF317LET/@@download/ENCFF317LET.bam')
#Download bam 2 day 1
os.system('wget https://www.encodeproject.org/files/ENCFF765GMR/@@download/ENCFF765GMR.bam')

#Download bam 1 day 2
os.system('wget https://www.encodeproject.org/files/ENCFF688HAO/@@download/ENCFF688HAO.bam')
#Download bam 2 day 2
os.system('wget https://www.encodeproject.org/files/ENCFF863YVC/@@download/ENCFF863YVC.bam')

#Download bam 1 day 3
os.system('wget https://www.encodeproject.org/files/ENCFF551HRO/@@download/ENCFF551HRO.bam')
#Download bam 2 day 3
os.system('wget https://www.encodeproject.org/files/ENCFF698XGG/@@download/ENCFF698XGG.bam')

#Merge bam files 1 and 2 for each day with samtools

#Day 1
merge1="samtools merge Day1_alignment.bam ENCFF317LET.bam ENCFF765GMR.bam"
os.system(merge1)

#Day 2
merge2="samtools merge -f Day2_alignment.bam ENCFF688HAO.bam ENCFF863YVC.bam"
#subprocess.check_output(merge2, shell=True)
os.system(merge2)
#Day 3
merge3="samtools merge -f Day3_alignment.bam ENCFF551HRO.bam ENCFF698XGG.bam"
#subprocess.check_output(merge3, shell=True)
os.system(merge3)