
#!/usr/bin/python3

import os, sys, subprocess, shutil

#Download fasta for reference genome
os.system('wget https://www.encodeproject.org/files/mm10_no_alt_analysis_set_ENCODE/@@download/mm10_no_alt_analysis_set_ENCODE.fasta.gz')

##Unzip fasta file
os.system('gunzip mm10_no_alt_analysis_set_ENCODE.fasta.gz')

##bgzip fasta file
os.system('bgzip mm10_no_alt_analysis_set_ENCODE.fasta')

#Run TOBIAS ATACorrect
os.system('TOBIAS ATACorrect --bam Day1_alignment.bam --genome mm10_no_alt_analysis_set_ENCODE.fasta.gz --peaks Enhancerpeaks_3times_merged.bed --cores 8')
os.system('TOBIAS ATACorrect --bam Day2_alignment.bam --genome mm10_no_alt_analysis_set_ENCODE.fasta.gz --peaks Enhancerpeaks_3times_merged.bed --cores 8')
os.system('TOBIAS ATACorrect --bam Day3_alignment.bam --genome mm10_no_alt_analysis_set_ENCODE.fasta.gz --peaks Enhancerpeaks_3times_merged.bed --cores 8')

#Run BigWig
os.system('TOBIAS FootprintScores --signal Day1_alignment_corrected.bw --regions Enhancerpeaks_3times_merged.bed --output Day1_footprints.bw --cores 8')
os.system('TOBIAS FootprintScores --signal Day2_alignment_corrected.bw --regions Enhancerpeaks_3times_merged.bed --output Day2_footprints.bw --cores 8')
os.system('TOBIAS FootprintScores --signal Day3_alignment_corrected.bw --regions Enhancerpeaks_3times_merged.bed --output Day3_footprints.bw --cores 8')