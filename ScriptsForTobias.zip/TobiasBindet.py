
#!/usr/bin/python3

import os, sqlite3, _sqlite3

os.system('TOBIAS BINDetect --motifs JASPAR2020_Mus-musculus_memes-new.txt --signals Day1_footprints.bw --genome mm10_no_alt_analysis_set_ENCODE.fasta.gz --peaks Enhancerpeaks_3times_merged.bed --outdir TobiasBindetect/Day11.5 --cond_names Day11.5 --cores 8')

os.system('TOBIAS BINDetect --motifs JASPAR2020_Mus-musculus_memes-new.txt --signals Day2_footprints.bw --genome mm10_no_alt_analysis_set_ENCODE.fasta.gz --peaks Enhancerpeaks_3times_merged.bed --outdir TobiasBindetect/Day12.5 --cond_names Day12.5 --cores 8')

os.system('TOBIAS BINDetect --motifs JASPAR2020_Mus-musculus_memes-new.txt --signals Day3_footprints.bw --genome mm10_no_alt_analysis_set_ENCODE.fasta.gz --peaks Enhancerpeaks_3times_merged.bed --outdir TobiasBindetect/Day13.5 --cond_names Day13.5 --cores 8')

os.system('TOBIAS BINDetect --motifs JASPAR2020_Mus-musculus_memes-new.txt --signals Day1_footprints.bw Day2_footprints.bw Day3_footprints.bw --genome mm10_no_alt_analysis_set_ENCODE.fasta.gz --peaks Enhancerpeaks_3times_merged.bed --outdir BINDetect_Timeline_output --time-series --cores 8')