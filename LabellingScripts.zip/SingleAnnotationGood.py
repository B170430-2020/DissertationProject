#!/usr/bin/python3

import os, sys, subprocess, shutil, pandas as pd, numpy as np
from collections import Counter

##Script for Single Peak annotation NOT removing "." annotation ############################################################
##Day 11.5##################################################################################################################
df=pd.read_csv('Enhancerpeaks_AnnotatedColl_just11.5.bed',header=None, sep='\t')
header= ['chrom', 'chromStart', 'chromEnd', 'chromAnno', 'startAnno', 'endAnno', 'Annotation', 'V1', 'V2','V3', 'V4', 'V5', 'bp']
df.columns = header[:len(df.columns)]
#print(df)

df1=df.groupby(['chrom','chromStart','chromEnd', 'Annotation'], as_index=False).agg({'bp':['sum']})
df1.columns=[ 'chrom',  'chromStart',    'chromEnd', 'Annotation','bp']
#print(df1)
#print(df1.shape)
df1_idx = df1.groupby(['chrom','chromStart','chromEnd'], as_index=False).agg({'bp':['idxmax']})
df1_final = df1.iloc[df1_idx[('bp', 'idxmax')].values]

print(set(df1_final['Annotation']))
print(Counter(df1_final['Annotation']))
print(df1_final)

del df1_final['bp']
print(df1_final)

#df1_final.to_csv("Enhancerpeaks_SingleAnnotColl_11.5.tsv", header=False, index=False , sep='\t')
df1_final.to_csv("Enhancerpeaks_SingleAnnotColl_11.5.bed", header=False, index=False , sep='\t')


##Day 12.5###################################################################################################################
df=pd.read_csv('Enhancerpeaks_AnnotatedColl_just12.5.bed',header=None, sep='\t')

header= ['chrom', 'chromStart', 'chromEnd', 'chromAnno', 'startAnno', 'endAnno', 'Annotation', 'V1', 'V2','V3', 'V4', 'V5', 'bp']
df.columns = header[:len(df.columns)]
#print(df)

df1=df.groupby(['chrom','chromStart','chromEnd', 'Annotation'], as_index=False).agg({'bp':['sum']})
df1.columns=[ 'chrom',  'chromStart',    'chromEnd', 'Annotation','bp']
#print(df1)
#print(df1.shape)
df1_idx = df1.groupby(['chrom','chromStart','chromEnd'], as_index=False).agg({'bp':['idxmax']})
df1_final = df1.iloc[df1_idx[('bp', 'idxmax')].values]

print(set(df1_final['Annotation']))
print(Counter(df1_final['Annotation']))
print(df1_final)

del df1_final['bp']
print(df1_final)

#df1_final.to_csv("Enhancerpeaks_SingleAnnotColl_12.5.tsv", header=False, index=False , sep='\t')
df1_final.to_csv("Enhancerpeaks_SingleAnnotColl_12.5.bed", header=False, index=False, sep='\t')

##Day 13.5######################################################################################################################
df=pd.read_csv('Enhancerpeaks_AnnotatedColl_just13.5.bed',header=None, sep='\t')
header= ['chrom', 'chromStart', 'chromEnd', 'chromAnno', 'startAnno', 'endAnno', 'Annotation', 'V1', 'V2','V3', 'V4', 'V5', 'bp']
df.columns = header[:len(df.columns)]
#print(df)
df1=df.groupby(['chrom','chromStart','chromEnd', 'Annotation'], as_index=False).agg({'bp':['sum']})
df1.columns=[ 'chrom',  'chromStart',    'chromEnd', 'Annotation','bp']
#print(df1)
#print(df1.shape)
df1_idx = df1.groupby(['chrom','chromStart','chromEnd'], as_index=False).agg({'bp':['idxmax']})
df1_final = df1.iloc[df1_idx[('bp', 'idxmax')].values]

print(set(df1_final['Annotation']))
print(Counter(df1_final['Annotation']))
print(df1_final)

del df1_final['bp']
print(df1_final)

#df1_final.to_csv("Enhancerpeaks_SingleAnnotColl_13.5.tsv", header=False, index=False , sep='\t')
df1_final.to_csv("Enhancerpeaks_SingleAnnotColl_13.5.bed", header=False, index=False, sep='\t')


  




