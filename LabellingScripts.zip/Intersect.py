
#!/usr/bin/python3

import os, sys, subprocess, shutil
'''
#Download annotation day 11.5
os.system('wget https://www.encodeproject.org/files/ENCFF749VMS/@@download/ENCFF749VMS.bed.gz')
#Download annotation day 12.5
os.system('wget https://www.encodeproject.org/files/ENCFF242PDA/@@download/ENCFF242PDA.bed.gz')
#Download annotation day 13.5
os.system('wget https://www.encodeproject.org/files/ENCFF197PCI/@@download/ENCFF197PCI.bed.gz')

os.system('gunzip ENCFF749VMS.bed.gz')
os.system('gunzip ENCFF242PDA.bed.gz')
os.system('gunzip ENCFF197PCI.bed.gz')
'''
#Annotate merged file only day 11.5
intersect1="bedtools intersect -a Enhancerpeaks_3times_merged.bed -b ENCFF749VMS_coll.bed -wao -filenames >Enhancerpeaks_AnnotatedColl_just11.5.bed"
subprocess.check_output(intersect1, shell=True)

#Annotate merged file only day 12.5
intersect2="bedtools intersect -a Enhancerpeaks_3times_merged.bed -b ENCFF242PDA_coll.bed -wao -filenames >Enhancerpeaks_AnnotatedColl_just12.5.bed"
subprocess.check_output(intersect2, shell=True)

#Annotate merged file only day 13.5
intersect3="bedtools intersect -a Enhancerpeaks_3times_merged.bed -b ENCFF197PCI_coll.bed -wao -filenames >Enhancerpeaks_AnnotatedColl_just13.5.bed"
subprocess.check_output(intersect3, shell=True)

