
#!/usr/bin/python3

import os, sys, subprocess, shutil, pandas as pd, numpy as np
'''
#Download annotation day 11.5
os.system('wget https://www.encodeproject.org/files/ENCFF749VMS/@@download/ENCFF749VMS.bed.gz')
#Download annotation day 12.5
os.system('wget https://www.encodeproject.org/files/ENCFF242PDA/@@download/ENCFF242PDA.bed.gz')
#Download annotation day 13.5
os.system('wget https://www.encodeproject.org/files/ENCFF197PCI/@@download/ENCFF197PCI.bed.gz')

os.system('gunzip ENCFF749VMS.bed.gz')
os.system('gunzip ENCFF242PDA.bed.gz')
os.system('gunzip ENCFF197PCI.bed.gz')
'''
##Annotation for day 11.5##
df=pd.read_csv('ENCFF749VMS.bed',header=None, sep='\t')
header= ['chrom', 'chromStart', 'chromEnd','Annotation', 'V1', 'V2','V3', 'V4', 'V5']
df.columns = header[:len(df.columns)]
#print(df)
print((df.Annotation==".").count())
'''
df.loc[df.Annotation=="QuiesG","Annotation"]="Quies"
df.loc[df.Annotation=="Quies2","Annotation"]="Quies"
df.loc[df.Annotation=="Quies3","Annotation"]="Quies"
df.loc[df.Annotation=="Quies4","Annotation"]="Quies"
df.loc[df.Annotation=="EnhG","Annotation"]="Enh"
df.loc[df.Annotation=="EnhLo","Annotation"]="Enh"
df.loc[df.Annotation=="TssBiv","Annotation"]="Tss"
df.loc[df.Annotation=="TssFlnk","Annotation"]="Tss"
df.loc[df.Annotation=="TxWk","Annotation"]="Tx"
df.loc[df.Annotation=="ReprPCWk","Annotation"]="ReprPC"
'''
df['Annotation']=np.where((df.Annotation=="QuiesG"), "Quies", df.Annotation)
df['Annotation']=np.where((df.Annotation=="Quies2"), "Quies", df.Annotation)
df['Annotation']=np.where((df.Annotation=="Quies3"), "Quies", df.Annotation)
df['Annotation']=np.where((df.Annotation=="Quies4"), "Quies", df.Annotation)
df['Annotation']=np.where((df.Annotation=="EnhG"), "Enh", df.Annotation)
df['Annotation']=np.where((df.Annotation=="EnhLo"), "Enh", df.Annotation)
df['Annotation']=np.where((df.Annotation=="TssBiv"), "Tss", df.Annotation)
df['Annotation']=np.where((df.Annotation=="TssFlnk"), "Tss", df.Annotation)
df['Annotation']=np.where((df.Annotation=="TxWk"), "Tx", df.Annotation)
df['Annotation']=np.where((df.Annotation=="ReprPCWk"), "ReprPC", df.Annotation)


print(df)
print(set(df['Annotation']))

df.to_csv("ENCFF749VMS_coll.bed", header=False, index=False , sep='\t')


##Annotation for day 12.5##
df=pd.read_csv('ENCFF242PDA.bed',header=None, sep='\t')
header= ['chrom', 'chromStart', 'chromEnd','Annotation', 'V1', 'V2','V3', 'V4', 'V5']
df.columns = header[:len(df.columns)]
#print(df)
print((df.Annotation==".").count())

df['Annotation']=np.where((df.Annotation=="QuiesG"), "Quies", df.Annotation)
df['Annotation']=np.where((df.Annotation=="Quies2"), "Quies", df.Annotation)
df['Annotation']=np.where((df.Annotation=="Quies3"), "Quies", df.Annotation)
df['Annotation']=np.where((df.Annotation=="Quies4"), "Quies", df.Annotation)
df['Annotation']=np.where((df.Annotation=="EnhG"), "Enh", df.Annotation)
df['Annotation']=np.where((df.Annotation=="EnhLo"), "Enh", df.Annotation)
df['Annotation']=np.where((df.Annotation=="TssBiv"), "Tss", df.Annotation)
df['Annotation']=np.where((df.Annotation=="TssFlnk"), "Tss", df.Annotation)
df['Annotation']=np.where((df.Annotation=="TxWk"), "Tx", df.Annotation)
df['Annotation']=np.where((df.Annotation=="ReprPCWk"), "ReprPC", df.Annotation)


print(df)
print(set(df['Annotation']))

df.to_csv("ENCFF242PDA_coll.bed", header=False, index=False , sep='\t')

##Annotation for day 13.5##
df=pd.read_csv('ENCFF197PCI.bed',header=None, sep='\t')
header= ['chrom', 'chromStart', 'chromEnd','Annotation', 'V1', 'V2','V3', 'V4', 'V5']
df.columns = header[:len(df.columns)]
#print(df)
print((df.Annotation==".").count())

df['Annotation']=np.where((df.Annotation=="QuiesG"), "Quies", df.Annotation)
df['Annotation']=np.where((df.Annotation=="Quies2"), "Quies", df.Annotation)
df['Annotation']=np.where((df.Annotation=="Quies3"), "Quies", df.Annotation)
df['Annotation']=np.where((df.Annotation=="Quies4"), "Quies", df.Annotation)
df['Annotation']=np.where((df.Annotation=="EnhG"), "Enh", df.Annotation)
df['Annotation']=np.where((df.Annotation=="EnhLo"), "Enh", df.Annotation)
df['Annotation']=np.where((df.Annotation=="TssBiv"), "Tss", df.Annotation)
df['Annotation']=np.where((df.Annotation=="TssFlnk"), "Tss", df.Annotation)
df['Annotation']=np.where((df.Annotation=="TxWk"), "Tx", df.Annotation)
df['Annotation']=np.where((df.Annotation=="ReprPCWk"), "ReprPC", df.Annotation)


print(df)
print(set(df['Annotation']))

df.to_csv("ENCFF197PCI_coll.bed", header=False, index=False , sep='\t')